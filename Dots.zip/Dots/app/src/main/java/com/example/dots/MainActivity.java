package com.example.dots;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageView circle1, circle2, circle3, circle4, circle5, circle6, circle7, circle8, circle9, circle10, circle11, circle12;
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        circle1 = findViewById(R.id.circle_1);
        circle2 = findViewById(R.id.circle_2);
        circle3 = findViewById(R.id.circle_3);
        circle4 = findViewById(R.id.circle_4);
        circle5 = findViewById(R.id.circle_5);
        circle6 = findViewById(R.id.circle_6);
        circle7 = findViewById(R.id.circle_7);
        circle8 = findViewById(R.id.circle_8);
        circle9 = findViewById(R.id.circle_9);
        circle10 = findViewById(R.id.circle_10);
        circle11 = findViewById(R.id.circle_11);
        circle12 = findViewById(R.id.circle_12);

        startAnimation();
    }

    private void startAnimation() {
        new CountDownTimer(1000, 100) {

            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                if (counter == 0) {
                    circle5.setBackgroundResource(R.drawable.circle_red);
                    circle4.setBackgroundResource(R.drawable.circle_green);
                    circle3.setBackgroundResource(R.drawable.circle_blue);
                    circle6.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 1) {
                    circle4.setBackgroundResource(R.drawable.circle_red);
                    circle3.setBackgroundResource(R.drawable.circle_green);
                    circle2.setBackgroundResource(R.drawable.circle_blue);
                    circle5.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 2) {
                    circle3.setBackgroundResource(R.drawable.circle_red);
                    circle2.setBackgroundResource(R.drawable.circle_green);
                    circle1.setBackgroundResource(R.drawable.circle_blue);
                    circle4.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 3) {
                    circle2.setBackgroundResource(R.drawable.circle_red);
                    circle1.setBackgroundResource(R.drawable.circle_green);
                    circle11.setBackgroundResource(R.drawable.circle_blue);
                    circle3.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 4) {
                    circle1.setBackgroundResource(R.drawable.circle_red);
                    circle11.setBackgroundResource(R.drawable.circle_green);
                    circle12.setBackgroundResource(R.drawable.circle_blue);
                    circle2.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 5) {
                    circle11.setBackgroundResource(R.drawable.circle_red);
                    circle12.setBackgroundResource(R.drawable.circle_green);
                    circle10.setBackgroundResource(R.drawable.circle_blue);
                    circle1.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 6) {
                    circle12.setBackgroundResource(R.drawable.circle_red);
                    circle10.setBackgroundResource(R.drawable.circle_green);
                    circle9.setBackgroundResource(R.drawable.circle_blue);
                    circle11.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 7) {
                    circle10.setBackgroundResource(R.drawable.circle_red);
                    circle9.setBackgroundResource(R.drawable.circle_green);
                    circle8.setBackgroundResource(R.drawable.circle_blue);
                    circle12.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 8) {
                    circle9.setBackgroundResource(R.drawable.circle_red);
                    circle8.setBackgroundResource(R.drawable.circle_green);
                    circle7.setBackgroundResource(R.drawable.circle_blue);
                    circle10.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 9) {
                    circle8.setBackgroundResource(R.drawable.circle_red);
                    circle7.setBackgroundResource(R.drawable.circle_green);
                    circle6.setBackgroundResource(R.drawable.circle_blue);
                    circle9.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 10) {
                    circle7.setBackgroundResource(R.drawable.circle_red);
                    circle6.setBackgroundResource(R.drawable.circle_green);
                    circle5.setBackgroundResource(R.drawable.circle_blue);
                    circle8.setBackgroundResource(R.drawable.circle);
                    counter++;
                    startAnimation();
                } else if (counter == 11) {
                    circle6.setBackgroundResource(R.drawable.circle_red);
                    circle5.setBackgroundResource(R.drawable.circle_green);
                    circle4.setBackgroundResource(R.drawable.circle_blue);
                    circle7.setBackgroundResource(R.drawable.circle);
                    counter = 0;
                    startAnimation();
                }
            }
        }.start();
    }
}